WARNING* The save data file belongs applies to your own pc only. 
when you run the game on another pc, unlocked skins and coins will be gone. 
>*  backup the original file before apply the savefile *<

C:\Users\YOUR PC NAME\AppData\Local\Propnight\Saved\SaveGames   <---put the "SaveUserData.sav" file at here

*possibility of ban for 0%, but i dont responsibility for acc ban due to user issue.


Free to share,enjoy it!.

discord hihihi#5188
https://steamcommunity.com/profiles/76561199241090723/

------------------------------------------------------------------------------------------------------------------------------------------------


주의* 해당 세이브 데이터 파일은 개인 컴퓨터에 귀속됩니다. 
다른 컴퓨터에서 게임 실행 시 언락되어 있던 스킨, 코인은 모두 초기화 상태일 것입니다. 

>* 이전 데이터는 모두 사라지니 미리 백업해두세요 *<

C:\사용자\사용자 컴퓨터 이름\AppData\Local\Propnight\Saved\SaveGames
SaveGames 폴더속에 다운로드한 SaveUserData.sav파일을 덮어씌우면됩니다 다시 한번 말하지만 덮어씌우기 전에 이전 파일을 백업해두세요. 
그렇지 않으면 다른 컴퓨터(PC방)에서 스킨 무한 초기화 증상 발생 시 해결할 수 없습니다.

밴 가능성은 0%에 수렴하지만 사용자 부주의로 인한 밴은 책임지지 않습니다.

공유는 자유! 

디코 hihihi#5188
https://steamcommunity.com/profiles/76561199241090723/




